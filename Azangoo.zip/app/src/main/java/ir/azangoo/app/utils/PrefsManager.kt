package ir.azangoo.app.utils

import android.content.Context
import ir.azangoo.app.model.PrayerType

class PrefsManager(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("azangoo_prefs", Context.MODE_PRIVATE)

    var fajrEnabled: Boolean
        get() = prefs.getBoolean("adhan_fajr", true)
        set(value) = prefs.edit().putBoolean("adhan_fajr", value).apply()

    var dhuhrEnabled: Boolean
        get() = prefs.getBoolean("adhan_dhuhr", true)
        set(value) = prefs.edit().putBoolean("adhan_dhuhr", value).apply()

    var maghribEnabled: Boolean
        get() = prefs.getBoolean("adhan_maghrib", true)
        set(value) = prefs.edit().putBoolean("adhan_maghrib", value).apply()

    var customAudioUri: String?
        get() = prefs.getString("custom_audio_uri", null)
        set(value) = prefs.edit().putString("custom_audio_uri", value).apply()

    var customAudioName: String?
        get() = prefs.getString("custom_audio_name", null)
        set(value) = prefs.edit().putString("custom_audio_name", value).apply()

    var hijriOffsetDays: Int
        get() = prefs.getInt("hijri_offset_days", 0)
        set(value) = prefs.edit().putInt("hijri_offset_days", value.coerceIn(-2, 2)).apply()

    var useAlarmStream: Boolean
        get() = prefs.getBoolean("use_alarm_stream", true)
        set(value) = prefs.edit().putBoolean("use_alarm_stream", value).apply()

    fun isPrayerEnabled(type: PrayerType): Boolean = when (type) {
        PrayerType.FAJR -> fajrEnabled
        PrayerType.DHUHR -> dhuhrEnabled
        PrayerType.MAGHRIB -> maghribEnabled
        else -> false
    }
}
