package ir.azangoo.app.model

data class JalaliDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class HijriDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class GregorianDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class CalendarEvent(
    val title: String,
    val isHoliday: Boolean,
    val type: String
)

enum class PrayerType(val key: String, val persianName: String, val alarmId: Int) {
    FAJR("fajr", "اذان صبح", 1001),
    SUNRISE("sunrise", "طلوع آفتاب", 1002),
    DHUHR("dhuhr", "اذان ظهر", 1003),
    SUNSET("sunset", "غروب آفتاب", 1004),
    MAGHRIB("maghrib", "اذان مغرب", 1005),
    MIDNIGHT("midnight", "نیمه‌شب شرعی", 1006);

    companion object {
        fun fromKey(key: String?): PrayerType {
            return entries.firstOrNull { it.key == key } ?: DHUHR
        }
    }
}

data class PrayerTimeItem(
    val type: PrayerType,
    val hour: Int,
    val minute: Int
) {
    val totalMinutes: Int get() = hour * 60 + minute

    fun formattedEnglish(): String = String.format("%02d:%02d", hour, minute)
}

data class DailyPrayerTimes(
    val fajr: PrayerTimeItem,
    val sunrise: PrayerTimeItem,
    val dhuhr: PrayerTimeItem,
    val sunset: PrayerTimeItem,
    val maghrib: PrayerTimeItem,
    val midnight: PrayerTimeItem
) {
    fun allOrdered(): List<PrayerTimeItem> = listOf(fajr, sunrise, dhuhr, sunset, maghrib, midnight)
    fun adhanPrayers(): List<PrayerTimeItem> = listOf(fajr, dhuhr, maghrib)
}
