package ir.azangoo.app.ui

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.FragmentSettingsBinding
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.widget.AzangooWidgetProvider

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: PrefsManager

    private val audioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            handleSelectedAudio(uri)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        // Prayer switches
        binding.switchFajr.isChecked = prefs.fajrEnabled
        binding.switchDhuhr.isChecked = prefs.dhuhrEnabled
        binding.switchMaghrib.isChecked = prefs.maghribEnabled
        binding.switchAlarmStream.isChecked = prefs.useAlarmStream

        binding.switchFajr.setOnCheckedChangeListener { _, isChecked ->
            prefs.fajrEnabled = isChecked
            AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchDhuhr.setOnCheckedChangeListener { _, isChecked ->
            prefs.dhuhrEnabled = isChecked
            AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchMaghrib.setOnCheckedChangeListener { _, isChecked ->
            prefs.maghribEnabled = isChecked
            AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchAlarmStream.setOnCheckedChangeListener { _, isChecked ->
            prefs.useAlarmStream = isChecked
        }

        // Audio picker
        binding.btnPickAudio.setOnClickListener {
            audioPickerLauncher.launch(arrayOf("audio/*"))
        }

        binding.btnClearAudio.setOnClickListener {
            prefs.customAudioUri = null
            prefs.customAudioName = null
            updateAudioLabel()
            Toast.makeText(requireContext(), "فایل سفارشی حذف شد (صدای پیش‌فرض گوشی)", Toast.LENGTH_SHORT).show()
        }

        binding.btnTestAudio.setOnClickListener {
            val ctx = requireContext()
            if (AdhanPlaybackService.isPlaying) {
                AdhanPlaybackService.stopPlayback(ctx)
            } else {
                val intent = Intent(ctx, AdhanPlaybackService::class.java).apply {
                    action = AdhanPlaybackService.ACTION_START
                    putExtra(AdhanPlaybackService.EXTRA_IS_TEST, true)
                }
                ContextCompat.startForegroundService(ctx, intent)
                Toast.makeText(ctx, "برای قطع پخش، روی اعلان یا دکمه توقف بزنید", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnStopTestAudio.setOnClickListener {
            AdhanPlaybackService.stopPlayback(requireContext())
        }

        // Hijri offset adjustment
        binding.btnHijriMinus.setOnClickListener {
            prefs.hijriOffsetDays = (prefs.hijriOffsetDays - 1).coerceAtLeast(-2)
            updateHijriOffsetUi()
            AzangooWidgetProvider.updateAllWidgets(requireContext())
        }
        binding.btnHijriPlus.setOnClickListener {
            prefs.hijriOffsetDays = (prefs.hijriOffsetDays + 1).coerceAtMost(2)
            updateHijriOffsetUi()
            AzangooWidgetProvider.updateAllWidgets(requireContext())
        }

        // Battery optimization helper
        binding.btnBatteryOptimization.setOnClickListener {
            openBatteryOptimizationSettings()
        }

        // Exact alarm helper
        binding.btnExactAlarm.setOnClickListener {
            openExactAlarmSettings()
        }

        updateAudioLabel()
        updateHijriOffsetUi()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatuses()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun handleSelectedAudio(uri: Uri) {
        val ctx = requireContext()
        try {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
        }

        val displayName = queryFileName(ctx, uri) ?: "فایل صوتی انتخاب‌شده"
        prefs.customAudioUri = uri.toString()
        prefs.customAudioName = displayName
        updateAudioLabel()
        Toast.makeText(ctx, "فایل اذان ذخیره شد: $displayName", Toast.LENGTH_SHORT).show()
    }

    private fun queryFileName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun updateAudioLabel() {
        val name = prefs.customAudioName
        if (name.isNullOrBlank()) {
            binding.tvSelectedAudio.text = "فایل انتخاب‌شده: پیش‌فرض گوشی (فایل دلخواه انتخاب نشده)"
            binding.btnClearAudio.visibility = View.GONE
        } else {
            binding.tvSelectedAudio.text = "فایل انتخاب‌شده: $name"
            binding.btnClearAudio.visibility = View.VISIBLE
        }
    }

    private fun updateHijriOffsetUi() {
        val offset = prefs.hijriOffsetDays
        val label = when {
            offset > 0 -> "+${PersianCalendarUtils.toPersianDigits(offset)} روز"
            offset < 0 -> "${PersianCalendarUtils.toPersianDigits(offset)} روز"
            else -> "۰ (پیش‌فرض)"
        }
        binding.tvHijriOffsetValue.text = label
    }

    private fun updatePermissionStatuses() {
        val ctx = requireContext()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val ignoringBattery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        binding.tvBatteryStatus.text = if (ignoringBattery) "وضعیت: بدون محدودیت (عالی)" else "وضعیت: دارای محدودیت باتری (توصیه می‌شود فعال کنید)"
        binding.tvBatteryStatus.setTextColor(
            ContextCompat.getColor(ctx, if (ignoringBattery) R.color.azangoo_primary else R.color.azangoo_holiday)
        )

        val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
        binding.tvExactAlarmStatus.text = if (canExact) "وضعیت: فعال و دقیق" else "وضعیت: نیاز به فعال‌سازی"
        binding.tvExactAlarmStatus.setTextColor(
            ContextCompat.getColor(ctx, if (canExact) R.color.azangoo_primary else R.color.azangoo_holiday)
        )
    }

    private fun openBatteryOptimizationSettings() {
        val ctx = requireContext()
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${ctx.packageName}")
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${requireContext().packageName}")
                }
                startActivity(intent)
            } catch (_: Exception) {
            }
        } else {
            Toast.makeText(requireContext(), "در این نسخه اندروید، آلارم دقیق به صورت خودکار فعال است.", Toast.LENGTH_SHORT).show()
        }
    }
}
