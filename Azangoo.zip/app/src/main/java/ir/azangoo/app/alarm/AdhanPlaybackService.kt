package ir.azangoo.app.alarm

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import ir.azangoo.app.AzangooApp
import ir.azangoo.app.R
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.AdhanAlertActivity
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager

class AdhanPlaybackService : Service() {

    companion object {
        const val ACTION_START = "ir.azangoo.app.SERVICE_START_ADHAN"
        const val ACTION_STOP = "ir.azangoo.app.SERVICE_STOP_ADHAN"
        const val EXTRA_IS_TEST = "extra_is_test"
        const val BROADCAST_STATE_CHANGED = "ir.azangoo.app.ADHAN_STATE_CHANGED"
        private const val NOTIFICATION_ID = 7701

        @Volatile
        var isPlaying: Boolean = false
            private set

        @Volatile
        var currentTitle: String = ""
            private set

        fun stopPlayback(context: Context) {
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAndRelease()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val prayerKey = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY)
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""
                val isTest = intent.getBooleanExtra(EXTRA_IS_TEST, false)
                val prayerType = PrayerType.fromKey(prayerKey)
                val title = if (isTest) "تست پخش اذان" else "${prayerType.persianName} به افق تهران"
                startAdhan(title, prayerTime, isTest)
            }
        }
        return START_NOT_STICKY
    }

    private fun startAdhan(title: String, timeText: String, isTest: Boolean) {
        releasePlayerOnly()
        acquireWakeLock()

        currentTitle = title
        isPlaying = true
        notifyStateChanged()

        val notification = buildNotification(title, timeText, isTest)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Launch tap-anywhere-to-stop alert screen (for scheduled Adhan)
        if (!isTest) {
            try {
                val alertIntent = Intent(this, AdhanAlertActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("title", title)
                    putExtra("time", timeText)
                }
                startActivity(alertIntent)
            } catch (_: Exception) {
            }
        }

        val prefs = PrefsManager(this)
        val audioUsage = if (prefs.useAlarmStream) {
            AudioAttributes.USAGE_ALARM
        } else {
            AudioAttributes.USAGE_MEDIA
        }

        val attrs = AudioAttributes.Builder()
            .setUsage(audioUsage)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val uriToPlay = resolveAudioUri(prefs)

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(applicationContext, uriToPlay)
                setOnCompletionListener {
                    stopAndRelease()
                }
                setOnErrorListener { _, _, _ ->
                    playFallback(attrs)
                    true
                }
                prepare()
                start()
            }
            mediaPlayer = mp
        } catch (_: Exception) {
            playFallback(attrs)
        }
    }

    private fun resolveAudioUri(prefs: PrefsManager): Uri {
        val custom = prefs.customAudioUri
        if (!custom.isNullOrBlank()) {
            return Uri.parse(custom)
        }
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    private fun playFallback(attrs: AudioAttributes) {
        try {
            releasePlayerOnly()
            val fallbackUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(applicationContext, fallbackUri)
                setOnCompletionListener { stopAndRelease() }
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopAndRelease()
        }
    }

    private fun buildNotification(title: String, timeText: String, isTest: Boolean): Notification {
        // Tapping the notification itself immediately stops Adhan!
        val stopIntent = Intent(this, AdhanPlaybackService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            9001,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alertIntent = Intent(this, AdhanAlertActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("title", title)
            putExtra("time", timeText)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            9002,
            alertIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val subtitle = if (timeText.isNotBlank()) {
            "ساعت ${PersianCalendarUtils.toPersianDigits(timeText)} • برای قطع اذان لمس کنید"
        } else {
            "برای قطع پخش اذان، همین‌جا را لمس کنید"
        }

        val builder = NotificationCompat.Builder(this, AzangooApp.CHANNEL_ADHAN_ID)
            .setSmallIcon(R.drawable.ic_mosque)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(stopPendingIntent)
            .addAction(R.drawable.ic_stop, "قطع اذان", stopPendingIntent)

        if (!isTest) {
            builder.setFullScreenIntent(fullScreenPendingIntent, true)
        }

        return builder.build()
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Azangoo::AdhanWakeLock")
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(10 * 60 * 1000L) // Max 10 minutes
            }
        } catch (_: Exception) {
        }
    }

    private fun releasePlayerOnly() {
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    private fun stopAndRelease() {
        releasePlayerOnly()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        isPlaying = false
        currentTitle = ""
        notifyStateChanged()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyStateChanged() {
        val intent = Intent(BROADCAST_STATE_CHANGED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        releasePlayerOnly()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        isPlaying = false
        super.onDestroy()
    }
}
