package ir.azangoo.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import ir.azangoo.app.R
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.MainActivity
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrayerTimeCalculator
import java.util.Calendar

class AzangooWidgetProvider : AppWidgetProvider() {

    companion object {
        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, AzangooWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                for (id in ids) {
                    updateAppWidget(context, manager, id)
                }
            }
        }

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_azangoo)

            val todayG = PersianCalendarUtils.todayGregorian()
            val todayJ = PersianCalendarUtils.gregorianToJalali(todayG.year, todayG.month, todayG.day)
            val times = PrayerTimeCalculator.calculateForTehran(todayG)

            val now = Calendar.getInstance()
            val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

            val nextPrayer = times.allOrdered().firstOrNull { it.totalMinutes > nowMin } ?: times.fajr

            views.setTextViewText(
                R.id.widget_date,
                "${PersianCalendarUtils.formatJalaliFull(todayJ)} • تهران"
            )
            views.setTextViewText(
                R.id.widget_next_prayer,
                "وعده بعدی: ${nextPrayer.type.persianName} (${PersianCalendarUtils.toPersianDigits(nextPrayer.formattedEnglish())})"
            )

            views.setTextViewText(R.id.w_time_fajr, PersianCalendarUtils.toPersianDigits(times.fajr.formattedEnglish()))
            views.setTextViewText(R.id.w_time_sunrise, PersianCalendarUtils.toPersianDigits(times.sunrise.formattedEnglish()))
            views.setTextViewText(R.id.w_time_dhuhr, PersianCalendarUtils.toPersianDigits(times.dhuhr.formattedEnglish()))
            views.setTextViewText(R.id.w_time_sunset, PersianCalendarUtils.toPersianDigits(times.sunset.formattedEnglish()))
            views.setTextViewText(R.id.w_time_maghrib, PersianCalendarUtils.toPersianDigits(times.maghrib.formattedEnglish()))
            views.setTextViewText(R.id.w_time_midnight, PersianCalendarUtils.toPersianDigits(times.midnight.formattedEnglish()))

            val boxMap = mapOf(
                PrayerType.FAJR to R.id.w_box_fajr,
                PrayerType.SUNRISE to R.id.w_box_sunrise,
                PrayerType.DHUHR to R.id.w_box_dhuhr,
                PrayerType.SUNSET to R.id.w_box_sunset,
                PrayerType.MAGHRIB to R.id.w_box_maghrib,
                PrayerType.MIDNIGHT to R.id.w_box_midnight
            )
            for ((type, viewId) in boxMap) {
                val bg = if (type == nextPrayer.type) R.drawable.bg_widget_highlight else 0
                views.setInt(viewId, "setBackgroundResource", bg)
            }

            val launchIntent = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context,
                3001,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }
}
