package ir.azangoo.app.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import ir.azangoo.app.R
import ir.azangoo.app.databinding.FragmentTodayBinding
import ir.azangoo.app.model.DailyPrayerTimes
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.utils.EventsRepository
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrayerTimeCalculator
import ir.azangoo.app.utils.PrefsManager
import java.util.Calendar

class TodayFragment : Fragment() {

    private var _binding: FragmentTodayBinding? = null
    private val binding get() = _binding!!

    private val handler = Handler(Looper.getMainLooper())
    private var todayTimes: DailyPrayerTimes? = null

    private val ticker = object : Runnable {
        override fun run() {
            updateCountdownAndHighlight()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        bindTodayData()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun bindTodayData() {
        val ctx = requireContext()
        val prefs = PrefsManager(ctx)

        val todayG = PersianCalendarUtils.todayGregorian()
        val todayJ = PersianCalendarUtils.gregorianToJalali(todayG.year, todayG.month, todayG.day)
        val todayH = PersianCalendarUtils.gregorianToHijri(todayG.year, todayG.month, todayG.day, prefs.hijriOffsetDays)

        binding.tvJalaliDate.text = PersianCalendarUtils.formatJalaliFull(todayJ)
        binding.tvHijriGregorian.text =
            "${PersianCalendarUtils.formatHijriFull(todayH)}  •  ${PersianCalendarUtils.formatGregorianFull(todayG)}"

        val times = PrayerTimeCalculator.calculateForTehran(todayG)
        todayTimes = times

        binding.tvTimeFajr.text = PersianCalendarUtils.toPersianDigits(times.fajr.formattedEnglish())
        binding.tvTimeSunrise.text = PersianCalendarUtils.toPersianDigits(times.sunrise.formattedEnglish())
        binding.tvTimeDhuhr.text = PersianCalendarUtils.toPersianDigits(times.dhuhr.formattedEnglish())
        binding.tvTimeSunset.text = PersianCalendarUtils.toPersianDigits(times.sunset.formattedEnglish())
        binding.tvTimeMaghrib.text = PersianCalendarUtils.toPersianDigits(times.maghrib.formattedEnglish())
        binding.tvTimeMidnight.text = PersianCalendarUtils.toPersianDigits(times.midnight.formattedEnglish())

        // Show alarm active badges for the 3 Adhan prayers
        binding.badgeFajr.text = if (prefs.fajrEnabled) "پخش فعال" else "خاموش"
        binding.badgeDhuhr.text = if (prefs.dhuhrEnabled) "پخش فعال" else "خاموش"
        binding.badgeMaghrib.text = if (prefs.maghribEnabled) "پخش فعال" else "خاموش"

        val activeColor = ContextCompat.getColor(ctx, R.color.azangoo_primary)
        val mutedColor = ContextCompat.getColor(ctx, R.color.azangoo_text_secondary)
        binding.badgeFajr.setTextColor(if (prefs.fajrEnabled) activeColor else mutedColor)
        binding.badgeDhuhr.setTextColor(if (prefs.dhuhrEnabled) activeColor else mutedColor)
        binding.badgeMaghrib.setTextColor(if (prefs.maghribEnabled) activeColor else mutedColor)

        // Occasions for today
        val events = EventsRepository.getEventsForDate(ctx, todayJ, todayH)
        if (events.isEmpty()) {
            binding.tvTodayEvents.text = "مناسبت خاصی برای امروز ثبت نشده است."
        } else {
            val sb = StringBuilder()
            events.forEachIndexed { idx, ev ->
                if (idx > 0) sb.append("
")
                val tag = if (ev.isHoliday) " (تعطیل رسمی)" else ""
                sb.append("• ").append(ev.title).append(tag)
            }
            binding.tvTodayEvents.text = sb.toString()
        }

        updateCountdownAndHighlight()
    }

    private fun updateCountdownAndHighlight() {
        val times = todayTimes ?: return
        val now = Calendar.getInstance()
        val nowSec = now.get(Calendar.HOUR_OF_DAY) * 3600 +
            now.get(Calendar.MINUTE) * 60 +
            now.get(Calendar.SECOND)

        val ordered = times.allOrdered()
        var nextItem = ordered.firstOrNull { it.totalMinutes * 60 > nowSec }
        val remainingSec: Int
        if (nextItem != null) {
            remainingSec = nextItem.totalMinutes * 60 - nowSec
        } else {
            nextItem = times.fajr
            remainingSec = (24 * 3600 - nowSec) + (times.fajr.totalMinutes * 60)
        }

        val h = remainingSec / 3600
        val m = (remainingSec % 3600) / 60
        val s = remainingSec % 60
        val countdownStr = PersianCalendarUtils.toPersianDigits(String.format("%02d:%02d:%02d", h, m, s))

        binding.tvNextPrayerLabel.text = "تا ${nextItem.type.persianName} (${PersianCalendarUtils.toPersianDigits(nextItem.formattedEnglish())})"
        binding.tvCountdown.text = countdownStr

        highlightRow(nextItem.type)
    }

    private fun highlightRow(nextType: PrayerType) {
        val ctx = context ?: return
        val normalBg = ContextCompat.getColor(ctx, android.R.color.transparent)
        val highlightBg = ContextCompat.getColor(ctx, R.color.azangoo_highlight_row)

        val rows: Map<PrayerType, View> = mapOf(
            PrayerType.FAJR to binding.rowFajr,
            PrayerType.SUNRISE to binding.rowSunrise,
            PrayerType.DHUHR to binding.rowDhuhr,
            PrayerType.SUNSET to binding.rowSunset,
            PrayerType.MAGHRIB to binding.rowMaghrib,
            PrayerType.MIDNIGHT to binding.rowMidnight
        )
        rows.forEach { (type, view) ->
            view.setBackgroundColor(if (type == nextType) highlightBg else normalBg)
        }
    }
}
