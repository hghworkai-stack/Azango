package ir.azangoo.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import ir.azangoo.app.model.GregorianDate
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.MainActivity
import ir.azangoo.app.utils.PrayerTimeCalculator
import ir.azangoo.app.utils.PrefsManager
import java.util.Calendar

object AdhanScheduler {

    const val ACTION_PLAY_ADHAN = "ir.azangoo.app.ACTION_PLAY_ADHAN"
    const val ACTION_REFRESH_WIDGET = "ir.azangoo.app.ACTION_REFRESH_WIDGET"
    const val EXTRA_PRAYER_KEY = "extra_prayer_key"
    const val EXTRA_PRAYER_TIME = "extra_prayer_time"

    private const val WIDGET_REFRESH_REQ_CODE = 2099

    fun scheduleAll(context: Context) {
        val prefs = PrefsManager(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Cancel existing adhan alarms first
        listOf(PrayerType.FAJR, PrayerType.DHUHR, PrayerType.MAGHRIB).forEach { type ->
            cancelAlarm(context, alarmManager, type.alarmId, ACTION_PLAY_ADHAN)
        }

        val now = Calendar.getInstance()
        val today = GregorianDate(
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH) + 1,
            now.get(Calendar.DAY_OF_MONTH)
        )
        val tomorrowCal = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val tomorrow = GregorianDate(
            tomorrowCal.get(Calendar.YEAR),
            tomorrowCal.get(Calendar.MONTH) + 1,
            tomorrowCal.get(Calendar.DAY_OF_MONTH)
        )

        val todayTimes = PrayerTimeCalculator.calculateForTehran(today)
        val tomorrowTimes = PrayerTimeCalculator.calculateForTehran(tomorrow)

        val pairs = listOf(
            Pair(todayTimes.fajr, tomorrowTimes.fajr),
            Pair(todayTimes.dhuhr, tomorrowTimes.dhuhr),
            Pair(todayTimes.maghrib, tomorrowTimes.maghrib)
        )

        for ((todayItem, tomorrowItem) in pairs) {
            if (!prefs.isPrayerEnabled(todayItem.type)) continue

            val targetCal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, todayItem.hour)
                set(Calendar.MINUTE, todayItem.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            var chosenItem = todayItem

            // If today's prayer already passed (including within last 10s), schedule tomorrow's
            if (targetCal.timeInMillis <= now.timeInMillis + 10_000L) {
                targetCal.set(Calendar.YEAR, tomorrow.year)
                targetCal.set(Calendar.MONTH, tomorrow.month - 1)
                targetCal.set(Calendar.DAY_OF_MONTH, tomorrow.day)
                targetCal.set(Calendar.HOUR_OF_DAY, tomorrowItem.hour)
                targetCal.set(Calendar.MINUTE, tomorrowItem.minute)
                targetCal.set(Calendar.SECOND, 0)
                targetCal.set(Calendar.MILLISECOND, 0)
                chosenItem = tomorrowItem
            }

            scheduleExactPrayer(
                context = context,
                alarmManager = alarmManager,
                triggerAtMillis = targetCal.timeInMillis,
                type = chosenItem.type,
                timeFormatted = chosenItem.formattedEnglish()
            )
        }

        scheduleNextWidgetRefresh(context, alarmManager)
    }

    private fun scheduleExactPrayer(
        context: Context,
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        type: PrayerType,
        timeFormatted: String
    ) {
        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            action = ACTION_PLAY_ADHAN
            putExtra(EXTRA_PRAYER_KEY, type.key)
            putExtra(EXTRA_PRAYER_TIME, timeFormatted)
        }
        val operation = PendingIntent.getBroadcast(
            context,
            type.alarmId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = PendingIntent.getActivity(
            context,
            type.alarmId + 50,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
            } else {
                val info = AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent)
                alarmManager.setAlarmClock(info, operation)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
        }
    }

    private fun scheduleNextWidgetRefresh(context: Context, alarmManager: AlarmManager) {
        val now = Calendar.getInstance()
        val today = GregorianDate(
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH) + 1,
            now.get(Calendar.DAY_OF_MONTH)
        )
        val times = PrayerTimeCalculator.calculateForTehran(today).allOrdered()
        var nextTrigger: Long? = null

        for (item in times) {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, item.hour)
                set(Calendar.MINUTE, item.minute)
                set(Calendar.SECOND, 5)
                set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis > now.timeInMillis + 5_000L) {
                nextTrigger = cal.timeInMillis
                break
            }
        }

        if (nextTrigger == null) {
            val midnight = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            nextTrigger = midnight.timeInMillis
        }

        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            action = ACTION_REFRESH_WIDGET
        }
        val pi = PendingIntent.getBroadcast(
            context,
            WIDGET_REFRESH_REQ_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTrigger, pi)
    }

    private fun cancelAlarm(context: Context, alarmManager: AlarmManager, reqCode: Int, action: String) {
        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            this.action = action
        }
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            alarmManager.cancel(pi)
            pi.cancel()
        }
    }
}
