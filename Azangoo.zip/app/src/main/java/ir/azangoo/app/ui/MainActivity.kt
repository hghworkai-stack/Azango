package ir.azangoo.app.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.ActivityMainBinding
import ir.azangoo.app.widget.AzangooWidgetProvider

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val adhanStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updatePlayingBanner()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestNotificationPermissionIfNeeded()

        // Ensure alarms & widget are always up to date when opening the app
        AdhanScheduler.scheduleAll(this)
        AzangooWidgetProvider.updateAllWidgets(this)

        binding.bannerStopAdhan.setOnClickListener {
            AdhanPlaybackService.stopPlayback(this)
            updatePlayingBanner()
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_today -> {
                    showFragment(TodayFragment())
                    true
                }
                R.id.nav_calendar -> {
                    showFragment(CalendarFragment())
                    true
                }
                R.id.nav_settings -> {
                    showFragment(SettingsFragment())
                    true
                }
                else -> false
            }
        }

        if (savedInstanceState == null) {
            binding.bottomNav.selectedItemId = R.id.nav_today
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(AdhanPlaybackService.BROADCAST_STATE_CHANGED)
        ContextCompat.registerReceiver(this, adhanStateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        updatePlayingBanner()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(adhanStateReceiver)
        } catch (_: Exception) {
        }
    }

    private fun updatePlayingBanner() {
        if (AdhanPlaybackService.isPlaying) {
            binding.bannerStopAdhan.visibility = View.VISIBLE
            val title = AdhanPlaybackService.currentTitle.ifBlank { "اذان" }
            binding.tvBannerStopText.text = "$title در حال پخش است — برای قطع لمس کنید"
        } else {
            binding.bannerStopAdhan.visibility = View.GONE
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
