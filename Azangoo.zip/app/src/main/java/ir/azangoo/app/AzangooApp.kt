package ir.azangoo.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class AzangooApp : Application() {

    companion object {
        const val CHANNEL_ADHAN_ID = "azangoo_adhan_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ADHAN_ID,
                "پخش اذان",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اعلان و کنترل پخش اذان (با لمس قطع می‌شود)"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
